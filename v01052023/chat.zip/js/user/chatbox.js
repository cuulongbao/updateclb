function openForm() {
	if(!showChatBox){
		document.getElementById("myForm").style.display = "block";
		document.getElementsByClassName("open-button")[0].style.display = "none";
	}else{
		document.getElementById("chat-page").style.display = "block";
		document.getElementsByClassName("open-button")[0].style.display = "none";
	}
	
}

function closeForm() {
	document.getElementById("myForm").style.display = "none";
	document.getElementsByClassName("open-button")[0].style.display = "block";
} 

function closeChatBox(){
	if(showChatBox){
		document.getElementById("chat-page").style.display = "none";
		document.getElementsByClassName("open-button")[0].style.display = "block";
	}
	
}


