'use strict';

var usernamePage = document.querySelector('#username-page');
var usernameForm = document.querySelector('#usernameForm');
var connectingElement = document.querySelector('.connecting');
var stompClient = null;
var username = null;
var fullname = null;
var targetVal =null;
var phoneVal=null;
var showChatBox=false;

var website="http://localhost:8080";
//var website="wss://cuulongbao.com";
var headers={"Host":"localhost"};

if(hostport!==undefined){
	if(!document.URL.startsWith("http://localhost")){
		website=hostport;
	}
}
if(chatDomain ==undefined){
	var chatDomain =website;
}
if(chatDomain!="" && chatDomain.indexOf("localhost")!=-1){
	headers={"Host":"localhost"};
}else{
	var host=domain.replace("http://","");
	host=host.replace("https://","");
	headers={"Host":host};
}
console.log(headers);
//website="";
//var website="https://cuulongbao.com";//for cloudflare
console.log("chatDomain "+chatDomain);

const subscribe1="/topic/";
const subscribe2="/topic/public/";
const regEndpoint="/app/chat.addUser/";
const adminEndpoint="/app/receiver/admin";

function display(message) {
    var messageElement = document.createElement('li');
    if(message.type === 'CHAT') {
        messageElement.classList.add('chat-message');
        var avatarElement = document.createElement('i');
        var avatarText = document.createTextNode(message.sender[0]);
        avatarElement.appendChild(avatarText);
        avatarElement.style['background-color'] = getAvatarColor(message.sender);
        messageElement.appendChild(avatarElement);
        var usernameElement = document.createElement('span');
        var usernameText = document.createTextNode(message.fullname +" "+getTime());
        usernameElement.appendChild(usernameText);
        messageElement.appendChild(usernameElement);
		var textElement = document.createElement('p');
		var messageText = document.createTextNode(message.content);
		textElement.appendChild(messageText);
		messageElement.appendChild(textElement);
		messageArea.appendChild(messageElement);
		messageArea.scrollTop = messageArea.scrollHeight;
    }else{
		
	}
}



usernameForm.addEventListener('submit', function connect(event) {
	
	if(!$("#usernameForm").valid()){
		return;
	}
    fullname = document.querySelector('#name').value.trim();
    phoneVal = document.querySelector('#phone').value.trim();
    targetVal = document.querySelector('#target').value.trim();
	if(fullname=="admin"){
		event.preventDefault();
		return false;
	}
	if(!phoneVal){
		event.preventDefault();
		return false;
	}
	
	if(isNaN(phoneVal)){
		event.preventDefault();
		return false;
	}
		
	
    if(fullname) {
		
		username=fullname.trim().toLowerCase()+"-"+phoneVal;
	
		console.log(username);
		//alert(username);
        usernamePage.classList.add('hidden');
        chatPage.classList.remove('hidden');
        var socket = new SockJS(chatDomain+'/ws');
        stompClient = Stomp.over(socket);
        stompClient.connect(headers, function onConnected() {
			

           	stompClient.subscribe(`${subscribe1}${username}`, onMessageReceived);
			stompClient.subscribe(`${subscribe2}${username}`, onMessageReceived);

			stompClient.send(`${regEndpoint}${username}`,
                {},
                JSON.stringify({sender:username, type: 'JOIN',
					 fullname: fullname,
						target:targetVal,phone:phoneVal}  ));
            connectingElement.classList.add('hidden');
			showChatBox=true;
			
        }, function onError(error) {

            connectingElement.textContent = 'Could not connect to WebSocket server. Please refresh this page to try again!';
            connectingElement.style.color = 'red';

        });
    }
    event.preventDefault();

}, true);

messageForm.addEventListener('submit', function(){
	if(messageInput.value==""){
		return ;
	}
	const data={
			sender: username, 
			type: 'CHAT',
			target:"user",
			phone:phoneVal,
			fullname:fullname,
			content: messageInput.value,
		};
	stompClient.send(adminEndpoint,
                {},
                JSON.stringify(data)
       );
	display(data);
}, true)

function getTime(){
	const now = new Date();
	let hour = now.getHours();
	let minute = now.getMinutes();
	let period = hour < 12 ? "AM" : "PM";
	hour = hour % 12 || 12;
	minute = minute < 10 ? "0" + minute : minute;
	const formattedTime = hour + ":" + minute + " " + period;
	return formattedTime; // ví dụ: "4:30 PM"
}