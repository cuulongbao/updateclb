'use strict';


var chatPage = document.querySelector('#chat-page');
var messageForm = document.querySelector('#messageForm');
var messageInput = document.querySelector('#message');
var messageArea = document.querySelector('#messageArea');
var userArea=document.querySelector('#userArea');

var senderId="";
var targetphone="";
var colors = [
    '#2196F3', '#32c787', '#00BCD4', '#ff5652',
    '#ffc107', '#ff85af', '#FF9800', '#39bbb0'
];

function sendMessage(event) {
    var messageContent = messageInput.value.trim();

    if(messageContent && stompClient) {
        var chatMessage = {
            sender: username,
            content: messageInput.value,
			target: "user",
			fullname:fullname,
            type: 'CHAT'
        };

        stompClient.send("/app/chat.sendMessage", {}, JSON.stringify(chatMessage));
        messageInput.value = '';
    }
    event.preventDefault();
}
var audio = new Audio('/plugins/chat/sound/alert.mp3');
 

function onMessageReceived(payload) {
    var message = JSON.parse(payload.body);	
	var messageElement;
	 audio.play();
	 	//	alert(JSON.stringify(message));
    if(message.type === 'JOIN') {
		if(message.sender=="admin"){
			return;
		}
		messageElement = document.createElement('li');
		messageElement.setAttribute("id",message.sender);
       // messageElement.classList.add('event-message');
	    messageElement.classList.add('chat-message');
        message.content = message.fullname + ' joined!';
		var avatarElement = document.createElement('i');
        var avatarText = document.createTextNode(message.sender[0]);
        avatarElement.appendChild(avatarText);
        avatarElement.style['background-color'] = getAvatarColor(message.sender);
        messageElement.appendChild(avatarElement);
        var usernameElement = document.createElement('span');
        var usernameText = document.createTextNode(message.fullname +` (${message.phone})`);
        usernameElement.appendChild(usernameText);
        messageElement.appendChild(usernameElement);
		var textElement = document.createElement('p');
		var messageText = document.createTextNode(message.content);
		textElement.appendChild(messageText);
		messageElement.appendChild(textElement);
		userArea.appendChild(messageElement);
		userArea.scrollTop = userArea.scrollHeight;
		var ulElement = document.createElement('ul');
		userMap[message.sender]=ulElement;
		messageElement.addEventListener("click", function(){
			try{
				var id=senderId.replaceAll(" ","\\ ");
				id=id.replaceAll(".","\\.");
				var senderIdElement=document.querySelector('#'+id);
				senderIdElement.style['background-color'] = "rgb(255,255,255)";
			}catch(err){
				console.log(err);
			}
			senderId=message.sender;
			messageElement.style['background-color'] = "rgb(200,200,255)";

			while (messageArea.firstChild) {
				messageArea.removeChild(messageArea.lastChild);
			}
			let numb = userMap[senderId].childNodes.length;
			//alert(numb);
			for(var i=0;i<numb;i++){
					const clone=userMap[senderId].childNodes[i].cloneNode(true);
					messageArea.appendChild(clone);
			}
			//alert(clone.innerHtml);
		//	messageArea.innerHtml=clone.innerHtml;
		});
		return;
    } else if (message.type === 'LEAVE') {
		try{
			var messageElement=document.getElementById(message.sender);
			messageElement.parentNode.removeChild(messageElement);
			userMap.delete(message.sender);
		}catch(err){
			
		}
		return;
    } else {
		messageElement = document.createElement('li');
        messageElement.classList.add('chat-message');
        var avatarElement = document.createElement('i');
        var avatarText = document.createTextNode(message.sender[0]);
        avatarElement.appendChild(avatarText);
        avatarElement.style['background-color'] = getAvatarColor(message.sender);
		messageElement.appendChild(avatarElement);
		var usernameElement = document.createElement('span');
		var usernameText = document.createTextNode(message.fullname);
		usernameElement.appendChild(usernameText);
		messageElement.appendChild(usernameElement);
    }
	var textElement = document.createElement('p');
    var messageText = document.createTextNode(message.content);
    textElement.appendChild(messageText);
    messageElement.appendChild(textElement);
	//alert("messageElement.innerHtml "+messageElement.innerHTML);
	var clone = messageElement.cloneNode(true);
	//alert("clone.innerHtml "+clone.innerText);
	userMap[message.sender].appendChild(clone);
	//alert(userMap[message.sender].innerHtml);
	if(senderId==""){
		 messageArea.appendChild(messageElement);
	}else{
		if(message.sender==senderId){
			 messageArea.appendChild(messageElement);
		}
	}
    messageArea.scrollTop = messageArea.scrollHeight;
	//alert(userMap[message.sender].innerHtml);	
}

function getAvatarColor(messageSender) {
    var hash = 0;
    for (var i = 0; i < messageSender.length; i++) {
        hash = 31 * hash + messageSender.charCodeAt(i);
    }
    var index = Math.abs(hash % colors.length);
    return colors[index];
}
messageForm.addEventListener('submit', sendMessage, true);